import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Introduce tamaño n: ");
        int n = sc.nextInt();

        int constante = n * (n * n + 1) / 2;

        int[][] matriz;
        int intentos = 0;

        do {
            matriz = generarMatriz(n);
            intentos++;

            if (intentos % 100000 == 0) {
                System.out.print("\rBuscando solución... Intentos: " + intentos);
            }



        } while (!esCuadradoMagico(matriz, constante));


        System.out.println();

        System.out.println("Cuadrado mágico encontrado:");
        mostrarMatriz(matriz);
        System.out.println("Constante mágica: " + constante);
        System.out.println("Intentos: " + intentos);
    }


    public static int[][] generarMatriz(int n) {

        int[] numeros = new int[n * n];
        boolean[] usado = new boolean[n * n + 1];

        int[][] matriz = new int[n][n];

        for (int i = 0; i < n * n; i++) {

            int num;
            do {
                num = (int) (Math.random() * (n * n)) + 1;
            } while (usado[num]);

            numeros[i] = num;
            usado[num] = true;
        }

        int k = 0;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                matriz[i][j] = numeros[k++];
            }
        }

        return matriz;
    }


    public static boolean esCuadradoMagico(int[][] m, int constante) {

        int n = m.length;


        for (int i = 0; i < n; i++) {
            int suma = 0;
            for (int j = 0; j < n; j++) {
                suma += m[i][j];
            }
            if (suma != constante) return false;
        }


        for (int j = 0; j < n; j++) {
            int suma = 0;
            for (int i = 0; i < n; i++) {
                suma += m[i][j];
            }
            if (suma != constante) return false;
        }


        int d1 = 0, d2 = 0;
        for (int i = 0; i < n; i++) {
            d1 += m[i][i];
            d2 += m[i][n - 1 - i];
        }

        return d1 == constante && d2 == constante;
    }


    public static void mostrarMatriz(int[][] m) {
        for (int[] fila : m) {
            for (int v : fila) {
                System.out.printf("%4d", v);
            }
            System.out.println();
        }
    }
}
